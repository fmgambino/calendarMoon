<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="../css/welcomeAdmin.css">
    <link rel="stylesheet" type="text/css" href="../Librerias/ALERTIFY/css/alertify.css">
    <link rel="stylesheet" type="text/css" href="../Librerias/ALERTIFY/themes/default.css">
    <link rel="stylesheet" type="text/css" href="../Librerias/boostrap/css/bootstrap.css">
    <script src="../Librerias/boostrap/js/bootstrap.js" ></script>
    <script src="../Librerias/JQUERY/jquery-3.6.0.min.js"></script>
    <script src="../Librerias/ALERTIFY/alertify.js"></script>
    <title>Calendario della luna</title>
</head>
<body>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Calendario_Lunare</title>
</head>
<body>
        <div>
            <div>
              <h2 class="mb-4 text-white">Benvenuto</h2>
                  <button type="button" class="btn btn-danger" >
                      <a href="logout.php" class="text-white">Chudi sesion</a>
                 </button>
            </div>
           

                <div class="contenedorbtn"> 
                     <div>
                        <button type="button" class="btn btn-primary btn-lg" data-target="#calendario" data-toggle="modal" >Calendario</button>
                     </div>
                     <div>
                     <button type="button" class="btn btn-primary btn-circle btn-xl" data-target="#ventanaModalHoy" data-toggle="modal">Oggi<i class="fa fa-list"></i>
                            </button>
                    </div> 
                     <div>
                        <button type="button" class="btn btn-primary btn-lg" data-target="#glosario" data-toggle="modal">Glossario</button>
                    </div> 
                    <div>
                        <button type="button" class="btn btn-primary btn-lg" data-target="#topday" data-toggle="modal">Top Day</button>
                    </div>
                    <div>
                        
                    </div> 
                    <div>
                        
                    </div>
                    
                </div> 
        </div>

        <!--modal dia hoy -->
        <main class="container">
        <div class="modal" id="ventanaModalHoy"  tabindex="-1" role="dialog" aria-labelledby="tituloVentana" arial-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 id="tituloVentaa"><?php  $DateAndTime = date('d-m-Y');  
                            echo $DateAndTime;
                            ?></h5>
                        
                        <button class="close" data-dismiss="modal" aria-label="Cerrar">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>

                    <div class="modal-body">

                    <form action="upload.php" method="POST" enctype="multipart/form-data">
                            <div class="form-group">
                                 <input type="text" name="titulo">
                                <input name="fechaHoy" type="text" hidden value="<?php  $DateAndTime = date('d-m-Y');  
                            echo $DateAndTime;
                            ?>">
                                        
                                        
                                            <label for="imagen">Immagine:</label>
                                            <input type="file" name="foto" class="form">
                                            
                                        
                                       
                                    
                                <h6 class="h3 text-black"></h6>
                                    <textarea type="password" name="text1" formControlName="pass" class="form-control text-center" require></textarea>
                                <h6 class="h3 text-black"></h6>
                                    <textarea type="password" name="text2" formControlName="pass" class="form-control text-center" require></textarea>
                                <h6 class="h3 text-black"></h6>
                                    <textarea type="password" name="text3" formControlName="pass" class="form-control text-center" require></textarea>
                               
                            </div>
                            <div class="modal-footer">
                                <button class="btn btn-warning" type="button" data-dismiss="modal">
                                Chiudere
                                </button>
                                <button class="btn btn-success" type="submit" >
                                Accettare
                                </button>
                            </div>
                        </form>

                    </div>

                    
                </div>
            </div>
        </div>
    </main>


    <!--modal dia hoy-->


     <!-- Modal notificaciones -->
     
            <!-- Modal -->
            <div class="modal fade" id="notificaciones" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
              <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 id="">Notifiche</h5>
                        
                        <button class="close" data-dismiss="modal" aria-label="Cerrar">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body"> 
                        <form action="uploadNotificacion.php" method="POST" enctype="multipart/form-data">
                            <div class="form-group"> 
                                            <label for="imagen">Immagine:</label>
                                            <input type="file" name="foto" class="form"> 
                                <h6 class="h3 text-black">Inserisci un titolo </h6>
                                    <input type="text" name="text1" formControlName="pass" class="form-control text-center" require></input>
                                <h6 class="h3 text-black">Inserisci la descrizione della notifica</h6>
                                    <textarea type="" name="text2" formControlName="pass" class="form-control text-center" require></textarea>
                            </div>
                            <div class="modal-footer">
                                <button class="btn btn-warning" type="button" data-dismiss="modal">
                                Chiudere
                                </button>
                                <button class="btn btn-success" type="submit" >
                                Accettare
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
              </div>
            </div>
            <!-- fin  Modal notificaciones -->

            <!-- Modal glosario -->
            
            <!--  -->
             <div class="modal fade" id="glosario" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
               <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h2>Glosario</h2>
                        <button class="close" data-dismiss="modal" aria-label="Cerrar">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body"> 
                        <form action="uploadGlosario.php" method="POST" enctype="multipart/form-data">
                            <div class="form-group"> 
                                            <label for="imagen">Immagine:</label>
                                            <input type="file" name="foto" class="form"> 
                                <h6 class="h3 text-black">Inserisci un titolo</h6>
                                    <input type="text" name="text1" formControlName="pass" class="form-control text-center" require></input>
                                <h6 class="h3 text-black">Inserisci la descrizione della notifica</h6>
                                    <textarea type="" name="text2" formControlName="pass" class="form-control text-center" require></textarea>
                            </div>
                            <div class="modal-footer">
                                <button class="btn btn-warning" type="button" data-dismiss="modal">
                                Chiudere
                                </button>
                                <button class="btn btn-success" type="submit" >
                                Accettare
                                </button>
                            </div>
                        </form>
                    </div>
                 </div>
               </div>
            </div>
            <!-- fin modal glosario -->

             <!--modal top day -->
        <main class="container">
        <div class="modal" id="topday"  tabindex="-1" role="dialog" aria-labelledby="tituloVentana" arial-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                <div class="modal-header">
                        <h2>Toy Day</h2>
                        <button class="close" data-dismiss="modal" aria-label="Cerrar">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body"> 
                        <form action="uploadTopDay.php" method="POST" enctype="multipart/form-data">
                            <div class="form-group"> 
                                            <label for="imagen">Immagine:</label>
                                            <input type="file" name="foto" class="form"> 
                                <h6 class="h3 text-black">Inserisci un titolo</h6>
                                    <input type="text" name="text1" formControlName="pass" class="form-control text-center" require></input>
                                <h6 class="h3 text-black">Inserisci la descrizione della notifica</h6>
                                    <textarea type="" name="text2" formControlName="pass" class="form-control text-center" require></textarea>
                            </div>
                            <div class="modal-footer">
                                <button class="btn btn-warning" type="button" data-dismiss="modal">
                                Chiudere
                                </button>
                                <button class="btn btn-success" type="submit" >
                                Accettare
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </main>


    <!--fin modal top day-->

     <!-- calendario -->
     <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#calendario" hidden></button>

         <!-- Moda calendario -->
            <div class="modal fade" id="calendario" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
              <div class="modal-dialog" role="document">
              <div class="modal-content">
                    <div class="modal-header">
                        <h5>Calendario Lunare</h5>
                        <button class="close" data-dismiss="modal" aria-label="Cerrar">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <form action="upload1.php" method="POST" enctype="multipart/form-data">
                            <div class="form-group">
                                 <input type="date" placeholder="Inserire una data" name="fechaHoy">
                                 <label>Inserire una data</label><br><br>
                                 
                                 <div style="width: 90%;height: 450px;border: 1px solid #000;" >
                                     <input type="text" name="titulo" placeholder="Inserisci un titolo"><br><br>
                                     <textarea style="height: 200px;"type="tetxt" name="text1" formControlName="pass" class="form-control text-center" placeholder=""></textarea>
                                        <div style="float:right" class="form-control text-center">
                                             <h5 for="imagen" class="form-control text-center">Imagen:</h5>
                                             <input type="file" name="foto" class="form" class="form-control text-center"><br><br>
                                        </div>
                                 </div>
                                 <div style="width: 90%;height: 400px;border: 1px solid #000;" class="hide">
                                     <input type="text" name="titulo1" placeholder="Inserisci un titolo"><br><br>
                                     <textarea style="height: 200px;"type="tetxt" name="text2" formControlName="pass" class="form-control text-center" placeholder=""></textarea>
                                        <div style="float:right" class="form-control text-center">
                                             <h5 for="imagen1" class="form-control text-center">Imagen:</h5>
                                             <input type="file" name="foto" class="form" class="form-control text-center"><br><br>
                                        </div>
                                 </div>
                                 <div style="width: 90%;height: 400px;border: 1px solid #000;"class="hide">
                                     <input type="text" name="titulo2" placeholder="Inserisci un titolo"><br><br>
                                     <textarea style="height: 200px;"type="tetxt" name="text3" formControlName="pass" class="form-control text-center" placeholder=""></textarea>
                                        <div style="float:right" class="form-control text-center">
                                             <h5 for="imagen2" class="form-control text-center">Imagen:</h5>
                                             <input type="file" name="foto" class="form" class="form-control text-center"><br><br>
                                        </div>
                                 </div>
                                 <div style="width: 90%;height: 400px;border: 1px solid #000;" class="hide">
                                     <input type="text" name="titulo3" placeholder="Inserisci un titolo"><br><br>
                                     <textarea style="height: 200px;"type="tetxt" name="text4" formControlName="pass" class="form-control text-center" placeholder=""></textarea>
                                        <div style="float:right" class="form-control text-center">
                                             <h5 for="imagen3" class="form-control text-center">Imagen:</h5>
                                             <input type="file" name="foto" class="form" class="form-control text-center"><br><br>
                                        </div>
                                 </div>
                                 <div style="width: 90%;height: 400px;border: 1px solid #000;" class="hide">
                                     <input type="text" name="titulo4" placeholder="Inserisci un titolo"><br><br>
                                     <textarea style="height: 200px;"type="tetxt" name="text5" formControlName="pass" class="form-control text-center" placeholder=""></textarea>
                                        <div style="float:right" class="form-control text-center">
                                             <h5 for="imagen4" class="form-control text-center">Imagen:</h5>
                                             <input type="file" name="foto" class="form" class="form-control text-center"><br><br>
                                        </div>
                                 </div>
                                 
                               
                                
                                
                            </div>
                            <div class="modal-footer">
                                
                                <button class="btn btn-warning" type="button" data-dismiss="modal">
                                Chiudere
                                </button>
                                <button class="btn btn-success" type="submit" >
                                Accettare
                                </button>
                            </div>
                        </form>
                            <button id="botonRegistroDia" class="btn btn-success mas" oneclick="NuevoREgistroDia()">+</button>
                    </div>
              </div>
            </div>
     <!--modal dia a dia -->
     <main class="container">
        <div class="modal" id="dia"  tabindex="-1" role="dialog" aria-labelledby="tituloVentana" arial-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 id="tituloVentaa"></h5>
                        <button class="close" data-dismiss="modal" aria-label="Cerrar">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>

                    <div class="modal-body">

                        <form  action="" method="" >
                            <div class="form-group">
                                 <input type="text" name="titulo" disabled value="">
                                <input name="fechaHoy" type="text" hidden value="">
                                <h6 class="h3 text-black"></h6>
                                    <textarea type="password" name="text1" formControlName="pass" class="form-control text-center" require disabled></textarea>
                                <h6 class="h3 text-black"></h6>
                                    <textarea type="password" name="text2" formControlName="pass" class="form-control text-center" require disabled></textarea>
                                <h6 class="h3 text-black"></h6>
                                    <textarea type="password" name="text3" formControlName="pass" class="form-control text-center" require disabled></textarea>
                               
                            </div>
                            <div class="modal-footer">
                                <button class="btn btn-warning" type="button" data-dismiss="modal">
                                Chiudere
                                </button>
                                <button class="btn btn-success" type="button" data-target="#registroDia" data-toggle="modal">
                                Aggiungi nuovo record
                                </button>
                            </div>
                        </form>

                    </div>

                    
                </div>
            </div>
        </div>
    </main>


    <!--modal dia a dia -->
            <!--registro dia -->
    <main class="container">
        <div class="modal" id="registroDia"  tabindex="1" role="dialog" aria-labelledby="tituloVentana1" arial-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 id="tituloVentaa"></h5>
                        <button class="close" data-dismiss="modal" aria-label="Cerrar">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>

                    <div class="modal-body">

                        <form  action="registrarDia.php" method="POST" >
                            <div class="form-group">
                                <input name="fechaHoy" type="date" value="">
                                 <input type="text" name="titulo" placeholder="inserisci il titolo">
                                
                                <h6 class="h3 text-black"></h6>
                                    <textarea type="password" name="text1" formControlName="pass" class="form-control text-center" require></textarea>
                                <h6 class="h3 text-black"></h6>
                                    <textarea type="password" name="text2" formControlName="pass" class="form-control text-center" require></textarea>
                                <h6 class="h3 text-black"></h6>
                                    <textarea type="password" name="text3" formControlName="pass" class="form-control text-center" require></textarea>
                               
                            </div>
                            <div class="modal-footer">
                                <button class="btn btn-warning" type="button" data-dismiss="modal">
                                Chiudere
                                </button>
                                <button class="btn btn-success" type="submit" >
                                Accettare
                                </button>
                            </div>
                        </form>

                    </div>

                    
                </div>
            </div>
        </div>
    </main>


    <!--registro dia -->
            
</body>
    <script type="text/javascript" src="../Librerias/boostrap/js/jquery-3.2.1.slim.min.js"></script>
    <script type="text/javascript" src="../Librerias/boostrap/js/popper.min.js"></script>
    <script type="text/javascript" src="../Librerias/boostrap/js/bootstrap.min.js"></script>
</html>